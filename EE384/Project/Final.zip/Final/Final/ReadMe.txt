Images folder contains some images that can be used to watermark. You may also download any images you want to use. They also don't have to be in the image folder for the system to work. 
watermark2.jpg is the image that was used as a watermark. It is an image that says confidential. You are also welcome to use a different image however I do not know what affect that will have on the original watermark during embedding process. 

You will be prompted for an image to watermark. 
Then prompted for the watermark image and what method LSB or DCT you want to use. 
The program will run the correct algorithm and display the images along with PSNR, SSIM, and computation time values. 
The watermarked image will be saved in the top folder structure.
Any subsequent runs of the system using the same method will overwrite the previously saved watermarked image. 
